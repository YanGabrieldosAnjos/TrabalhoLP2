/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.startv.banco;

import com.startv.negocio.Categoria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Bianca
 */
public class CategoriaDAO {
    
    public boolean inserirCategoria(Categoria a){

     int resposta=0;
       try{
       String sql = "insert into tvmaster.categoria values (?,?)";
       Connection conn = ConnectionFactory1.getConnection();
       PreparedStatement p = conn.prepareStatement(sql);
       p.setString(1,null);
       p.setString(2,a.getNome());
      resposta = p.executeUpdate();
         
       }
       
       catch(SQLException e){
           
       }
       finally{
         if (resposta>0)
            return true;
         else
             return false;
 
       }
       
    }
    
    
    
    
}
