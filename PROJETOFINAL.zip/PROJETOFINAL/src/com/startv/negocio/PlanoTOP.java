
package com.startv.negocio;

/**
 *
 * @author Bianca
 */
public class PlanoTOP extends Plano {
       
    
}
