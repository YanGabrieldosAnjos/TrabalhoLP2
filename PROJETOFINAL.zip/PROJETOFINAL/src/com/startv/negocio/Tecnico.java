package com.startv.negocio;


/**
 *
 * @author joice
 */
public class Tecnico extends Funcionario {

    public Tecnico(int senha, String funcao, String nome, String email, String cpf, String telefone) {
        super(senha, funcao, nome, email, cpf, telefone);
    }
    
}
