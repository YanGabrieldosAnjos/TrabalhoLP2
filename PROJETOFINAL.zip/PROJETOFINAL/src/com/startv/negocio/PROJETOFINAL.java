
package com.startv.negocio;

public class PROJETOFINAL {

    public static void main(String[] args) {
       
        
      /*  //Criacao de canal
        Canal a = new Canal (30, "1");
        Canal b = new Canal (40, "2");
        Canal c = new Canal (20, "3");
        Canal d = new Canal (10, "4");
        Canal e = new Canal (5, "5");
        Canal f = new Canal (10, "6");
        
        //Criacao de categorias
        Categoria um = new Categoria("filme", 1);
        Categoria dois = new Categoria ("infantil", 2);
        Categoria tres = new Categoria ("noticia", 3);
        Categoria quatro = new Categoria ("esporte", 4);
        
        //Adicionar os canais às categorias
        um.addCanal(a);//70
        um.addCanal(b);
       
        dois.addCanal(c);//30
        dois.addCanal(d);
        
        tres.addCanal(e);//15
        tres.addCanal(f);
        
        quatro.addCanal(c);//30
        quatro.addCanal(f);
        
        
        //Criar o plano e adicionar as categorias
        PlanoTOP plano1 = new PlanoTOP ();
        plano1.addCategoria(dois);
        plano1.addCategoria(um);
        plano1.addCategoria(tres);
        
        plano1.calcValor();
        System.out.println(plano1.toString());

        
       //Criar outro plano
       PlanoIlimitado plano2 = new PlanoIlimitado();
       plano2.addCategoria(um);
       plano2.addCategoria(dois);
       plano2.addCategoria(tres);
       plano2.addCategoria(quatro);
 
       plano2.calcValor();
       System.out.println(plano2.toString());
        
       //Criar outro plano
      PlanoRegular plano3 = new PlanoRegular();
      plano3.addCategoria(um);
      plano3.addCategoria(tres);
      
      plano3.calcValor();
      System.out.println(plano3.toString());
        */
        
        
    }
    
    
    
}
