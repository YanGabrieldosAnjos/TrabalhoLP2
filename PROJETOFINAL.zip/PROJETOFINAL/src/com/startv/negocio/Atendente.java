/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.startv.negocio;


/**
 *
 * @author joice
 */
public class Atendente extends Funcionario {

    public Atendente(int senha, String funcao, String nome, String email, String cpf, String telefone) {
        super(senha, funcao, nome, email, cpf, telefone);
    }
    
}
