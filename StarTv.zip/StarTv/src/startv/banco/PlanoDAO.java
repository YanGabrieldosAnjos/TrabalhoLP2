/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startv.banco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import startv.negocio.Plano;

/**
 *
 * @author Bianca
 */
public class PlanoDAO {
    
    
    public boolean create (Plano a){
      
      Connection conn = ConnectionFactory.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = conn.prepareStatement("INSERT INTO startv.plano (nome) values (?)");
            stmt.setString(1,a.getNome());
            stmt.executeUpdate();
            return true;

        } catch (SQLException ex) {
            return false;

        }
        
        finally{
         ConnectionFactory.closeConnection(conn, stmt);

        }   
    
    
    
}
    
    
    
     public List<Plano> read(String nome) {
        
       Connection conn = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List <Plano> planos = new ArrayList<>();

        try {
            stmt = conn.prepareStatement("SELECT * FROM startv.plano WHERE nome LIKE ?");
            stmt.setString(1, "%"+nome+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                Plano plano1 = new Plano() {};
    
                plano1.setId(rs.getInt("idplano"));
                plano1.setNome(rs.getString("nome"));                
                planos.add(plano1);
            }

        } catch (SQLException ex) {
         
        } finally {
            ConnectionFactory.closeConnection(conn, stmt, rs);
        }

        return planos;
    }
    
    
    
    
    
    
    
    public boolean update (Plano a){
      
      Connection conn = ConnectionFactory.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = conn.prepareStatement("UPDATE startv.plano SET nome= ? WHERE idplano = ?");
            stmt.setString(1,a.getNome());
            stmt.setInt(2,a.getId());
                    
            stmt.executeUpdate();
            return true;

        } catch (SQLException ex) {
            return false;

        }
        
        finally{
         ConnectionFactory.closeConnection(conn, stmt);

        }   
 
    }
    
      
    public boolean delete(Plano a){
      
      Connection conn = ConnectionFactory.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = conn.prepareStatement("DELETE FROM startv.plano WHERE idplano = ?");
            stmt.setInt(1,a.getId());
                    
            stmt.executeUpdate();
            return true;

        } catch (SQLException ex) {
            return false;

        }
        
        finally{
         ConnectionFactory.closeConnection(conn, stmt);

        }   
 
    }
    
    
}   
