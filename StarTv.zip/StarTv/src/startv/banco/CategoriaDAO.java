/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startv.banco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import startv.negocio.Categoria;
/**
 *
 * @author Bianca
 */
public class CategoriaDAO {
        
    public boolean create (Categoria a){
      
      Connection conn = ConnectionFactory.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = conn.prepareStatement("INSERT INTO startv.categoria (nomeCategoria) values (?)");
            stmt.setString(1,a.getNome());
            stmt.executeUpdate();
            return true;

        } catch (SQLException ex) {
            return false;

        }
        
        finally{
         ConnectionFactory.closeConnection(conn, stmt);

        }   
  
    }
    
    
    public List<Categoria> read(String nome) {
        
       Connection conn = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List <Categoria> categorias = new ArrayList<>();

        try {
            stmt = conn.prepareStatement("SELECT * FROM startv.categoria WHERE nomeCategoria LIKE ?");
            stmt.setString(1, "%"+nome+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                Categoria categoria = new Categoria();
    
                categoria.setId(rs.getInt("idcategoria"));
                categoria.setNome(rs.getString("nome"));                
                categorias.add(categoria);
            }

        } catch (SQLException ex) {

        } finally {
            ConnectionFactory.closeConnection(conn, stmt, rs);
        }

        return categorias;
    }
    
    public boolean update (Categoria a){
      
      Connection conn = ConnectionFactory.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = conn.prepareStatement("UPDATE startv.categoria SET nome= ? WHERE idCategoria = ?");
            stmt.setString(1,a.getNome());
            stmt.setInt(2,a.getId());
                    
            stmt.executeUpdate();
            return true;

        } catch (SQLException ex) {
            return false;

        }
        
        finally{
         ConnectionFactory.closeConnection(conn, stmt);

        }   
 
    }
    
    
     
    public boolean delete(Categoria a){
      
      Connection conn = ConnectionFactory.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = conn.prepareStatement("DELETE FROM startv.categoria WHERE idCategoria = ?");
            stmt.setInt(1,a.getId());
                    
            stmt.executeUpdate();
            return true;

        } catch (SQLException ex) {
            return false;

        }
        
        finally{
         ConnectionFactory.closeConnection(conn, stmt);

        }   
 
    }
    
    
    
    
    
   
}
  
    
    
    
    
    
    
    
    
    


