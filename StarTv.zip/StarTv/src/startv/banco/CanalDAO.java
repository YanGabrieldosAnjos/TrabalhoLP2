/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startv.banco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import startv.negocio.Canal;

/**
 *
 * @author Bianca
 */
public class CanalDAO {
    
    public boolean create (Canal a){
      
      Connection conn = ConnectionFactory.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = conn.prepareStatement("INSERT INTO startv.canal (nomeCanal, classEtaria, precoBase, ) values (?,?,?,?)");
            stmt.setString(1,a.getNome());
            stmt.setString(2,a.getClassificacao());
            stmt.setFloat(3,a.getPreco());
            
            
            stmt.executeUpdate();
            return true;

        } catch (SQLException ex) {
            return false;

        }
        
        finally{
         ConnectionFactory.closeConnection(conn, stmt);

        }   
  
    }
    
    
    public List<Canal> read(String nome) {
        
       Connection conn = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        List <Canal> canais = new ArrayList<>();
        try {
            stmt = conn.prepareStatement("SELECT * FROM startv.categoria WHERE descricao LIKE ?");
            stmt.setString(1, "%"+nome+"%");
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                Canal canal1 = new Canal();
    
                canal1.setId(rs.getInt("idcategoria"));
                canal1.setNome(rs.getString("nome"));                
                canais.add(canal1);
            }

        } catch (SQLException ex) {

        } finally {
            ConnectionFactory.closeConnection(conn, stmt, rs);
        }

        return canais;
    }
    
    public boolean update (Canal a){
      
      Connection conn = ConnectionFactory.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = conn.prepareStatement("UPDATE startv.canal SET nomeCanal= ?, classEtaria =?, precoBase=? WHERE idCanal = ?");
            stmt.setString(1,a.getNome());
            stmt.setString(2,a.getClassificacao());
            stmt.setFloat(3,a.getPreco());
            stmt.setInt(4,a.getId());

            
                    
            stmt.executeUpdate();
            return true;

        } catch (SQLException ex) {
            return false;

        }
        
        finally{
         ConnectionFactory.closeConnection(conn, stmt);

        }   
 
    }
    
    
     
    public boolean delete(Canal a){
      
      Connection conn = ConnectionFactory.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = conn.prepareStatement("DELETE FROM startv.categoria WHERE idcategoria = ?");
            stmt.setInt(1,a.getId());
                    
            stmt.executeUpdate();
            return true;

        } catch (SQLException ex) {
            return false;

        }
        
        finally{
         ConnectionFactory.closeConnection(conn, stmt);

        }   
 
    }
    
    
    
    
    
    
    
    
    
    
}
