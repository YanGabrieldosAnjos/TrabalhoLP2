/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startv.negocio;

import java.util.ArrayList;
import java.util.List;
import startv.banco.CategoriaDAO;

/**
 *
 * @author Bianca
 */
public class Categoria {
    private String nome;
    private float valor;
    private int id;
    
    ArrayList <Canal> canais = new ArrayList <Canal>();

    public Categoria(String nome) {
        this.nome = nome;
        
    }
    

    public Categoria() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
   
    public void addCanal(Canal a){
        canais.add(a);
    }
    
    public float calcValor(){
        float preco=0;
        for (int i=0;i<canais.size();i++){
            float a = canais.get(i).getPreco();
            preco = preco+a;
        }
        setValor(preco);
        return preco;
    }
    
    
      public boolean insere(){
        CategoriaDAO c = new CategoriaDAO();
        return c.create(this);
    }
    
      public boolean remove(){
        CategoriaDAO c = new CategoriaDAO();
        return c.delete(this);
      }
      
      
      public boolean altera(){
        CategoriaDAO c = new CategoriaDAO();
        return c.update(this);

      }
      
      public List<Categoria> pesquisa(String nome){
        CategoriaDAO c = new CategoriaDAO();
        return c.read(nome);
      }
      

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<Canal> getCanais() {
        return canais;
    }

    public void setCanais(ArrayList<Canal> canais) {
        this.canais = canais;
    }
    
     
    
}
