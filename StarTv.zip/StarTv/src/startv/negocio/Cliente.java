/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startv.negocio;

/**
 *
 * @author Bianca
 */
import java.util.ArrayList;
import startv.banco.ClienteDAO;
public class Cliente extends Pessoa {
    
    ArrayList <Contrato> listacontratos =new ArrayList<>();

    public Cliente( String nome, String cpf, String telefone, String email) {
        super(nome, cpf, telefone, email);
    }

  
    
}
