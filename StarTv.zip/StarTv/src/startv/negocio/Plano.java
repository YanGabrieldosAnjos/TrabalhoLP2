/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package startv.negocio;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bianca
 */
public class Plano {
    protected float preco;
    protected int id;
    protected String nome;
 
    ArrayList <Categoria> categorias = new ArrayList<Categoria>();

    public Plano() {
    }

    public void setId(int id) {
        this.id = id;
    }
    

    public Plano(String nome) {
        this.nome = nome;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<Categoria> getCategorias() {
        return categorias;
    }

    public void setCategorias(ArrayList<Categoria> categorias) {
        this.categorias = categorias;
    }

   
   /* public boolean incluir(){
        PlanoDAO a = new PlanoDAO();
        return a.create(this);
    }
    
    public boolean remove(){
        PlanoDAO a =  new PlanoDAO();
        return a.delete(this);
    }
    
    public boolean altera(){
        PlanoDAO a = new PlanoDAO();
        return a.update(this);
    }
    
    public List<Plano> pesquisa(String nome){
        PlanoDAO a = new PlanoDAO();
        return a.read(nome);
    }*/

    public void addCategoria(Categoria x){
        categorias.add(x);
    }

    public float calcValor(){
        for (int i=0;i<categorias.size();i++){
            preco = preco + categorias.get(i).calcValor();
          
        }
        return preco;
    }
        
    
    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public int getId() {
        return id;
    }

    
}
