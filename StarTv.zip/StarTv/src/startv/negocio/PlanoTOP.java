
package startv.negocio;

/**
 *
 * @author Bianca
 */
public class PlanoTOP extends Plano {
       
    public PlanoTOP(String nome) {
        super(nome);
    }
       
    
}
