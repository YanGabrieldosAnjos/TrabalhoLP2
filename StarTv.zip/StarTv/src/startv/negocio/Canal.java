package startv.negocio;

import java.util.List;
import startv.banco.CanalDAO;



/**
 *
 * @author joice
 */
public class Canal {
    private String Nome;
    private String Classificacao;
    private String Categoria;
    private float preco;
    private int id;

    
        public Canal (float preco, String Nome, String Classificacao, String Categoria){
      
        this.preco = preco;
        this.Categoria = Categoria;
        this.Classificacao = Classificacao;
        this.Nome = Nome;
        }

    public Canal() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
        
         public boolean insere(){
        CanalDAO c = new CanalDAO();
        return c.create(this);
    }
    
      public boolean remove(){
        CanalDAO c = new CanalDAO();
        return c.delete(this);
      }
      
      
      public boolean altera(){
        CanalDAO c = new CanalDAO();
        return c.update(this);

      }
      
      public List<Canal> pesquisa(String nome){
        CanalDAO c = new CanalDAO();
        return c.read(nome);
      }
      
        
        
        public void setCategoria (String Categoria){
                this.Categoria = Categoria;
            }
            
            public String getCategoria (){
                return Categoria;
            }
            
            public void setNome (String Nome){
                this.Nome = Nome;
            }
            
            public String getNome (){
                return Nome;
            }
            
            
            public void setClassificacao (String Classificacao){
                this.Classificacao = Classificacao;
            }
            
            public String getClassificacao (){
                return Classificacao;
            }
            
            public void setPreco (float preco){
                this.preco = preco;
            }
            
            public float getPreco (){
                return preco;
            }
            
    
}
